## pluginの利用方法 - FileLog
  URL: http://localhost:8302/plugins/select?redirect=/plugins

### 事前準備
- `docker-compose.yml`が所在フォルダに`logs`フォルダを作成しておく。
- 参考：`docker-compose.yml`でのvolume mapping
  ```yml
  ph1-kong:
    image: kong:3.5
    container_name: ph1-kong
    user: "${KONG_USER:-kong}"
    # 省略
    volumes:
      - ph1_kong_prefix_vol:${KONG_PREFIX:-/var/run/kong}
      - ph1_kong_tmp_vol:/tmp
      - ./volumes/logs:/logs
  ```
### pluginインストール
![Alt text](plugin-filelog-001.png)
### global適用
![Alt text](plugin-filelog-003.png)

### 出力したログ
`volumes/logs/kong.log`  ※整形後

#### logから解析できる情報　※一部
- request bodyのバイト数: `request.headers.content-length`
- response bodyのバイト数: `response.headers.content-length`
- ユーザー（consumer）: `consumer.username`
- アクセス先protocol： `service.protocol`
- アクセス先host： `service.host`
- アクセス先path： `upstream_uri`


```json
{
  "request": {
    "url": "http://localhost:8300/openai/v1/chat/completions",
    "querystring": {},
    "id": "54943b1403b2f0092a88381894236d44",
    "headers": {
      "content-length": "104",
      "accept": "*/*",
      "user-agent": "curl/7.80.0",
      "authorization": "REDACTED",
      "host": "localhost:8300",
      "x-consumer-username": "euler",
      "content-type": "application/json",
      "x-credential-identifier": "80d1e7d1-90ca-4f7d-94e3-6588f9611626",
      "x-consumer-id": "b11c314a-07b8-4ae8-8750-f5d25aff335c"
    },
    "size": 310,
    "uri": "/openai/v1/chat/completions",
    "method": "POST"
  },
  "response": {
    "size": 2351,
    "headers": {
      "content-length": "1017",
      "openai-organization": "user-znvhbtyyt03p3figusc83oa0",
      "openai-processing-ms": "3753",
      "access-control-allow-origin": "*",
      "strict-transport-security": "max-age=15724800; includeSubDomains",
      "x-ratelimit-limit-requests": "10000",
      "content-type": "application/json",
      "x-ratelimit-limit-tokens": "60000",
      "x-ratelimit-remaining-requests": "9999",
      "x-kong-request-id": "54943b1403b2f0092a88381894236d44",
      "x-ratelimit-remaining-tokens": "59978",
      "via": "kong/3.5.0",
      "x-ratelimit-reset-requests": "8.64s",
      "date": "Sun, 11 Feb 2024 02:01:18 GMT",
      "x-ratelimit-reset-tokens": "22ms",
      "x-kong-upstream-latency": "3995",
      "x-request-id": "req_6a2c10728e1af199c17d26873965cda1",
      "cache-control": "no-cache, must-revalidate",
      "cf-cache-status": "DYNAMIC",
      "connection": "close",
      "set-cookie": [
        "__cf_bm=xExT8FtLw0ds_NzUr9wIiVEa_F6WItleqOtr.joZBL8-1707616878-1-AfvOABXYwpXzMqciqwCraraf5hAbPwwAkGP33RLkKkdoFUYcwsOQH6JzbvbgrSLQdoY4ph6F5oDgtwx5UhkjZcs=; path=/; expires=Sun, 11-Feb-24 02:31:18 GMT; domain=.api.openai.com; HttpOnly; Secure; SameSite=None",
        "_cfuvid=C3m8zR4PBMMysb9vWRJohaV8jEtRr2L3Nx5Ksc.aSKw-1707616878860-0-604800000; path=/; domain=.api.openai.com; HttpOnly; Secure; SameSite=None"
      ],
      "alt-svc": "h3=\":443\"; ma=86400",
      "openai-version": "2020-10-01",
      "server": "cloudflare",
      "cf-ray": "853900bc3decf6a9-NRT",
      "x-kong-proxy-latency": "29",
      "openai-model": "gpt-3.5-turbo-0613"
    },
    "status": 200
  },
  "started_at": 1707616878377,
  "client_ip": "172.18.0.1",
  "tries": [
    {
      "port": 443,
      "balancer_start": 1707616878406,
      "balancer_start_ns": 1.7076168784061e+18,
      "balancer_latency_ns": 46336,
      "ip": "104.18.6.192",
      "balancer_latency": 0
    }
  ],
  "upstream_status": "200",
  "upstream_uri": "/v1/chat/completions",
  "consumer": {
    "id": "b11c314a-07b8-4ae8-8750-f5d25aff335c",
    "tags": [],
    "username": "euler",
    "created_at": 1707262498,
    "updated_at": 1707262498
  },
  "service": {
    "id": "ae737163-c6ae-48e3-b2de-b19231661a9e",
    "connect_timeout": 60000,
    "read_timeout": 60000,
    "created_at": 1707261313,
    "updated_at": 1707262356,
    "host": "api.openai.com",
    "protocol": "https",
    "name": "openai",
    "retries": 5,
    "port": 443,
    "write_timeout": 60000,
    "enabled": true,
    "ws_id": "e4a94e61-1402-4494-875b-6ce763a6e6f4"
  },
  "authenticated_entity": {
    "id": "80d1e7d1-90ca-4f7d-94e3-6588f9611626"
  },
  "latencies": {
    "request": 4024,
    "kong": 29,
    "proxy": 3995
  },
  "route": {
    "id": "6fd1f3d4-a15e-4bd8-b489-706a878fe4b1",
    "created_at": 1707261337,
    "updated_at": 1707261337,
    "path_handling": "v0",
    "preserve_host": false,
    "protocols": [
      "http",
      "https"
    ],
    "strip_path": true,
    "regex_priority": 0,
    "tags": [],
    "request_buffering": true,
    "response_buffering": true,
    "paths": [
      "/openai"
    ],
    "https_redirect_status_code": 426,
    "service": {
      "id": "ae737163-c6ae-48e3-b2de-b19231661a9e"
    },
    "ws_id": "e4a94e61-1402-4494-875b-6ce763a6e6f4"
  }
}
```