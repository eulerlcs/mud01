# serviceの単独利用

## 前提条件

`api4test`フォルダの`docker-compose.yml`で以下四つのcontainerが起動されてること。

- alpha:9001

- beta:9002

- gamma:9003

- omega:9004

  

操作対象URL：文字でQR code作成

  `http://localhost:9003/v1/create-qr-code?data=hello`



## service作成

![image-20240211181139289](service-201.png)

一覧から作成した`qr-service`を選択して、routeを作成する

![image-20240211181314188](service-203.png)

![image-20240211181424809](service-205.png)

## kong gatewayで動作確認

`http://localhost:8300/qr/v1/create-qr-code?data=hello`

![image-20240211181621502](service-207.png)

`https://localhost:8343/qr/v1/create-qr-code?data=hello`

![image-20240211181830122](service-209.png)