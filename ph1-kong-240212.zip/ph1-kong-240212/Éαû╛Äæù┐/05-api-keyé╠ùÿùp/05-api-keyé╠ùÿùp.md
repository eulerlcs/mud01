# 05-api-keyの利用

## 前提条件

`03-serviceの単独利用`が実施済



## key-authentication plugを追加する

​	

![image-20240211182446715](apikey-501.png)

![image-20240211182554911](apikey-503.png)

plugの設定

![image-20240211182700538](apikey-505.png)

![image-20240211182807476](apikey-507.png)

## consumer(user)作成

![image-20240211183014895](consumer-501.png)

作成したconsumer(user)を選択して、認証情報を生成する

![image-20240211183209272](consumer-503.png)

![image-20240211183320485](consumer-505.png)

![image-20240211183404846](consumer-507.png)



## 動作確認　apikeyが未設定する場合

![image-20240211183624512](result-001.png)

## 動作確認　apikeyが未設定した場合

![image-20240211183848205](result-003.png)