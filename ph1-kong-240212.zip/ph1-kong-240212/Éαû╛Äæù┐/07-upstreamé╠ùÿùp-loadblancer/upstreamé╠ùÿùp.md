## 前提条件

`api4test`フォルダの`docker-compose.yml`で以下四つのcontainerが起動されてること。

- alpha

- beta

- gamma

- omega

  上記の四つのmicroserviceにともに下記のAPIが定義している。

  `GET /api/v1/fast`



## step1 upsteam作成

Nameを入力した後に、下にスクールして、保存

![image-20240211173713038](upstream-001.png)

一覧から先ほど作成した`fast-upstream`を選択して、`New Target`を選択

![image-20240211174033234](upstream-003.png)

alpha microserviceのhostnameとportを入力して、保存

![image-20240211174155822](upstream-005.png)

beta, gamma, omegaも同様にtargetに追加しておく

![image-20240211174426590](upstream-007.png)

## step 2 service作成

New Gateway Service作成

![image-20240211174844668](service-401.png)

services 一覧から、先ほど作成した`fast-service`を選択して、routeを新規作成する

![image-20240211175041790](service-403.png)

routeのpathを設定する

![image-20240211175227000](service-405.png)

## step 3　動作確認する

`curl http://localhost:8300/sss/api/v1/fast`

![image-20240211175800226](confirm-401.png)



