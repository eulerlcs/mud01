import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.goto("https://www.yahoo.co.jp/")
    page.get_by_role("link", name="自民・麻生氏 総裁選前倒し要求へ NEW").click()
    page.get_by_role("link", name="IT", exact=True).click()
    page.get_by_role("link", name="Switch2 見えてきた実力と課題 NEW").click()
    page.get_by_text("多根清史アニメライター/ゲームライター京都大学法学部大学院修士課程卒。著書に『宇宙政治の政治経済学』（宝島社）、『ガンダムと日本人』（文春新書）、『教養としての").click()
