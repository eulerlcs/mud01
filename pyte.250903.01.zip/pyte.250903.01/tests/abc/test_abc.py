from src.abc.abc import tt


def test_main(capsys):
    tt()
    captured = capsys.readouterr()
    assert "Hello from pyte!" in captured.out
