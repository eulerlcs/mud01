import pytest

from src.abc.weather2 import get_weather_data


@pytest.mark.vcr
@pytest.mark.integration
def test_get_weather_data_tokyo():
    data = get_weather_data()
    assert data["latitude"] == 35.7
    assert data["longitude"] == 139.6875
    assert data["timezone"] == "Asia/Tokyo"
    assert data["elevation"] == 48.0


@pytest.mark.vcr
@pytest.mark.integration
def test_get_weather_data_osaka():
    data = get_weather_data(latitude=34.700267, longitude=135.501937)
    assert data["latitude"] == 34.7
    assert data["longitude"] == 135.5
    assert data["timezone"] == "Asia/Tokyo"
    assert data["elevation"] == 6.0

    data = get_weather_data(latitude=32, longitude=134)
    assert data["latitude"] == 32.0
    assert data["longitude"] == 134
    assert data["timezone"] == "Asia/Tokyo"
    assert data["elevation"] == 0


@pytest.mark.xfail
def test_abc():
    assert 1 == 2


@pytest.mark.parametrize("input, expected", [(1, 1), (2, 2), (3, 3)])
def test_params(input, expected):
    assert input == expected
