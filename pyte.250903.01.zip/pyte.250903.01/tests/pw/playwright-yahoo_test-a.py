import re

from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.goto("https://www.yahoo.co.jp/")

    firstArticle = page.locator('xpath=//*[@id="tabpanelTopics1"]/div[1]/div[1]/ul/li[1]/article/a/div/div/h1/span')
    firstArticle.click
    # page.get_by_role("link", name="東北 日本海側を中心に大雨の恐れ NEW").click()
    page.get_by_role("link", name="…記事全文を読む").click()
    # page.locator("#articleCommentModule").get_by_text("コメント37件").click()
