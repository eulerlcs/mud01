# pytest

```bash
conftest.py
pytest.ini

import _pytest.hookspec
```

## plugin

- allure-pytest
  - 前提-install allure <https://allurereport.org/docs/install-for-windows/>
  - [# Allure Reportを使って今風のイケてるテストレポートを作成しよう!](https://qiita.com/shun198/items/bb76d1eb98bb7290a6a8)
  - `allure generate -c .\tests_result\allure\data -o .\tests_result\allure\report`
- pytest-recording
  - `pytest --record-mode=new_episodes -m it`
- pytest-playwright
  - `playwright codegen https://www.yahoo.co.jp/`
  - `playwright codegen --target python-pytest -o aaa.py https://www.yahoo.co.jp`
  - `playwright install`
- pytest-playwright-asyncio
- pytest-log
- pytest-mock
  - 下記をclaude desktopに投げて、サンプルコードを生成してくれる
  - `pytest mock api assert、APIに実際に渡されたrequestの内容をassetするコートを教えて`
- pytest-cov
  - `pytest --cov src --cov-report=html:.test_result/coverage`
