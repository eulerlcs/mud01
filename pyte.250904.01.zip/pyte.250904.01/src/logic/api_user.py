import requests


# テスト対象のクラス/関数の例
class ApiUser:
    def __init__(self, base_url="http://localhost:8000"):
        self.base_url = base_url

    def create_user(self, name, email, age):
        url = f"{self.base_url}/users"
        payload = {"name": name, "email": email, "age": age}
        headers = {"Content-Type": "application/json", "Authorization": "Bearer token123"}
        response = requests.post(url, json=payload, headers=headers)
        return response.json()

    def get_user(self, user_id):
        url = f"{self.base_url}/users/{user_id}"
        headers = {"Authorization": "Bearer token123"}
        response = requests.get(url, headers=headers)
        return response.json()


def post_sample_user():
    # テスト実行
    client = ApiUser()
    result = client.create_user("太郎", "taro@example.com", 24)
    return result


def get_sample_user():
    client = ApiUser()
    result = client.get_user(123)
    return result
