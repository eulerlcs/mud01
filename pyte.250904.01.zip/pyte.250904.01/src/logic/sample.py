def tt():
    print("Hello from pyte!")
