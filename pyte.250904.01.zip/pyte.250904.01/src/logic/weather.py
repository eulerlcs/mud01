import requests

# res = requests.get("https://api.open-meteo.com/v1/forecast?latitude=35.6785&longitude=139.6823&timezone=Asia%2FTokyo")


def get_weather_data(latitude=35.6785, longitude=139.6823, timezone="Asia/Tokyo"):
    res = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": latitude,
            "longitude": longitude,
            "timezone": timezone,
        },
    )
    weather_data = res.json()
    print(weather_data)
    return weather_data


if __name__ == "__main__":
    weather_data = get_weather_data()
