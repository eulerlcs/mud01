import os

import pytest


@pytest.fixture(scope="session", autouse=True)
def setup():
    # 前処理
    print("テストはじめるよ")

    yield  # return -> yield (戻り値があれば yield something）

    # 後処理
    print("allure レポートを生成するよ")
    os.system("allure generate -c ./tests_result/allure/data -o ./tests_result/allure/report --clean")
