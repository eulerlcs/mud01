# pytest でモックされたAPIのリクエスト内容をアサートする例

from unittest.mock import MagicMock, patch

import pytest

from src.logic.api_user import get_sample_user, post_sample_user

# テスト対象のクラス/関数の例


# テストケース1: requests.postのモック
@pytest.mark.it
class TestApiUserPost:
    @patch("requests.post")
    def test_create_user_request_content(self, mock_post):
        # モックのレスポンス設定
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 1, "status": "created"}
        mock_post.return_value = mock_response

        # テスト実行
        post_sample_user()

        # モックが呼ばれたことを確認
        mock_post.assert_called_once()

        # 呼び出し時の引数を取得してアサート
        call_args = mock_post.call_args

        # URLのアサート
        assert call_args[0][0] == "http://localhost:8000/users"

        # JSONペイロードのアサート
        expected_payload = {"name": "太郎", "email": "taro@example.com", "age": 24}
        assert call_args.kwargs["json"] == expected_payload

        # ヘッダーのアサート
        expected_headers = {"Content-Type": "application/json", "Authorization": "Bearer token123"}
        assert call_args.kwargs["headers"] == expected_headers


# テストケース2: requests.getのモック
class TestApiUserGet:
    @patch("requests.get")
    def test_get_user_request_content(self, mock_get):
        # モックのレスポンス設定
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 123, "name": "太郎"}
        mock_get.return_value = mock_response

        # テスト実行
        get_sample_user()

        # より詳細なアサート方法
        mock_get.assert_called_once_with(
            "http://localhost:8000/users/123", headers={"Authorization": "Bearer token123"}
        )


# # テストケース3: call_args_listを使用した複数回呼び出しのテスト
# class TestMultipleCalls:
#     @patch('requests.post')
#     def test_multiple_api_calls(self, mock_post):
#         mock_response = MagicMock()
#         mock_response.json.return_value = {"status": "ok"}
#         mock_post.return_value = mock_response

#         client = ApiUser()

#         # 複数回API呼び出し
#         client.create_user("太郎", "taro@example.com", 25)
#         client.create_user("花子", "hanako@example.com", 30)

#         # 呼び出し回数の確認
#         assert mock_post.call_count == 2

#         # 各呼び出しの引数を個別にアサート
#         calls = mock_post.call_args_list

#         # 1回目の呼び出し
#         first_call = calls[0]
#         assert first_call.kwargs['json']['name'] == "太郎"
#         assert first_call.kwargs['json']['age'] == 25

#         # 2回目の呼び出し
#         second_call = calls[1]
#         assert second_call.kwargs['json']['name'] == "花子"
#         assert second_call.kwargs['json']['age'] == 30

# # テストケース4: assert_called_withを使用したシンプルなアサート
# class TestSimpleAssertions:
#     @patch('requests.post')
#     def test_create_user_simple_assert(self, mock_post):
#         mock_response = MagicMock()
#         mock_response.json.return_value = {"id": 1}
#         mock_post.return_value = mock_response

#         client = ApiUser()
#         client.create_user("太郎", "taro@example.com", 25)

#         # 期待される引数で呼び出されたかを直接アサート
#         mock_post.assert_called_with(
#             "http://localhost:8000/users",
#             json={
#                 "name": "太郎",
#                 "email": "taro@example.com",
#                 "age": 25
#             },
#             headers={
#                 "Content-Type": "application/json",
#                 "Authorization": "Bearer token123"
#             }
#         )

# # テストケース5: より複雑なリクエストボディのアサート
# class TestComplexRequestBody:
#     @patch('requests.post')
#     def test_complex_request_body_assertion(self, mock_post):
#         mock_response = MagicMock()
#         mock_response.json.return_value = {"success": True}
#         mock_post.return_value = mock_response

#         # 複雑なAPIクライアントの例
#         class ComplexApiUser:
#             def create_complex_user(self, user_data, options=None):
#                 payload = {
#                     "user": user_data,
#                     "metadata": {
#                         "created_at": "2024-01-01",
#                         "source": "web"
#                     }
#                 }
#                 if options:
#                     payload["options"] = options

#                 return requests.post(
#                     "http://localhost:8000/complex-users",
#                     json=payload,
#                     headers={"Content-Type": "application/json"}
#                 )

#         client = ComplexApiUser()
#         user_data = {"name": "太郎", "email": "taro@example.com"}
#         options = {"send_welcome_email": True}

#         client.create_complex_user(user_data, options)

#         # 呼び出された引数を取得
#         call_args = mock_post.call_args
#         actual_payload = call_args.kwargs['json']

#         # ネストされたデータのアサート
#         assert actual_payload['user']['name'] == "太郎"
#         assert actual_payload['user']['email'] == "taro@example.com"
#         assert actual_payload['metadata']['source'] == "web"
#         assert actual_payload['options']['send_welcome_email'] is True

# # テストケース6: リクエストの一部分だけをアサート（部分マッチ）
# class TestPartialAssertions:
#     @patch('requests.post')
#     def test_partial_request_assertion(self, mock_post):
#         mock_response = MagicMock()
#         mock_response.json.return_value = {"id": 1}
#         mock_post.return_value = mock_response

#         client = ApiUser()
#         client.create_user("太郎", "taro@example.com", 25)

#         # 呼び出された引数を取得
#         call_args = mock_post.call_args

#         # 特定のフィールドだけをアサート
#         json_payload = call_args.kwargs['json']
#         assert 'name' in json_payload
#         assert json_payload['name'] == "太郎"
#         assert json_payload['age'] > 0  # 年齢が正の値であることを確認

#         # ヘッダーに特定のキーが含まれていることを確認
#         headers = call_args.kwargs['headers']
#         assert 'Authorization' in headers
#         assert headers['Authorization'].startswith('Bearer ')

if __name__ == "__main__":
    # テスト実行例
    pytest.main([__file__, "-v"])
