import re

from playwright.sync_api import expect, sync_playwright


def main():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto("https://www.yahoo.co.jp")
        print(page.title())
        page.screenshot(path="tests_result/capture/logic/pw/playwright-hello/yahoo.co.jp.png")

        firstArticle = page.locator('xpath=//*[@id="tabpanelTopics1"]/div[1]/div[1]/ul/li[1]/article/a/div/div/h1/span')
        with page.expect_navigation():
            firstArticle.click()
        print(page.title())
        page.screenshot(path="tests_result/capture/logic/pw/playwright-hello/yahoo.co.jp-top-article.png")

        tbcLink = page.locator("div.sc-gdv5m1-8.eMtbmz > a").nth(0)

        expect(tbcLink).to_have_text(re.compile(r"記事全文を読む"))

        tbc = tbcLink.inner_text()
        print(tbc)

        assert re.match(r"記事全文を読む", tbc)
        # browser.close()


if __name__ == "__main__":
    main()
