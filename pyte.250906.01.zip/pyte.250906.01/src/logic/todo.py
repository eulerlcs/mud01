import requests


def get_todo(id=1):
    res = requests.get(f"https://jsonplaceholder.typicode.com/todos/{id}")
    return res.json()

if __name__ == "__main__":
    todo_data = get_todo()
    print(todo_data)
