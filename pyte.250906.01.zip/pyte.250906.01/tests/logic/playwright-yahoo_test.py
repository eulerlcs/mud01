import re

import pytest
from playwright.sync_api import Page, expect


@pytest.mark.st
def test_yahoo_top_article(page: Page) -> None:
    page.goto("https://www.yahoo.co.jp/")
    page.screenshot(path="tests_result/capture/logic/pw/playwright-hello/yahoo.co.jp.png")

    firstArticle = page.locator('xpath=//*[@id="tabpanelTopics1"]/div[1]/div[1]/ul/li[1]/article/a/div/div/h1/span')
    with page.expect_navigation():
        firstArticle.click()
    print(page.title())
    page.screenshot(path="tests_result/capture/logic/pw/playwright-hello/yahoo.co.jp-top-article.png")

    tbcLink = page.locator("div.sc-gdv5m1-8.eMtbmz > a").nth(0)

    expect(tbcLink).to_have_text(re.compile(r"記事全文を読む"))
