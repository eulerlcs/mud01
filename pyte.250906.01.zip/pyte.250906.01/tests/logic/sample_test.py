import pytest

from src.logic.sample import tt


def test_tt(capsys):
    tt()
    captured = capsys.readouterr()
    assert "Hello from pyte!" in captured.out


@pytest.mark.ut
@pytest.mark.xfail
def test_abc():
    assert 1 == 2


@pytest.mark.ut
@pytest.mark.parametrize("input, expected", [(1, 1), (2, 2), (3, 3)])
def test_params(input, expected):
    assert input == expected
