import pytest
import requests


@pytest.mark.it
@pytest.mark.vcr
def test_sample():
    res = requests.get("https://jsonplaceholder.typicode.com/todos/1").json()
    assert res["userId"] == 1
