import re

import pytest
from playwright.sync_api import Page, expect

from tests.test_common.common import load_test_data_from_csv

test_data = load_test_data_from_csv("tests/test_data/input/st/user/users-post-1by1.csv")
test_root_url = "http://localhost:8000/docs"


@pytest.mark.st
@pytest.mark.parametrize("user_name,user_email,user_age,user_active", test_data)
def test_users_post_1by1(page: Page, user_name, user_email, user_age, user_active) -> None:
    post_data = f"""
    {{
        "name": "{user_name}",
        "email": "{user_email}",
        "age": {user_age},
        "is_active": {user_active}
    }}
    """

    page.goto(test_root_url)
    locator = page.locator("#operations-default-create_user_users_post")
    locator.get_by_role("button", name="post /users", exact=True).click()
    locator.get_by_role("button", name="Try it out").click()
    locator.get_by_role("textbox").fill(post_data)
    locator.get_by_role("button", name="Execute").click()

    response_code = locator.get_by_role("table").get_by_role("cell").nth(2).inner_text()
    assert response_code == "200"


@pytest.mark.st
def test_users_upload_csv(page: Page) -> None:
    csvfile_path = "tests/test_data/input/st/user/users-upload-multi.csv"

    page.goto(test_root_url)
    page.get_by_role("button", name="post /users/upload/csv", exact=True).click()
    page.get_by_role("button", name="Try it out").click()
    page.get_by_role("button", name="Choose File").set_input_files(csvfile_path)
    page.get_by_role("button", name="Execute").click()
    response_code = page.get_by_role("table").get_by_role("cell").nth(4).inner_text()
    assert response_code == "200"


@pytest.mark.st
def test_users_download_csv(page: Page) -> None:
    save_path = "tests/test_data/output/st/user/users-download-csv.csv"

    page.goto(test_root_url)
    locator = page.locator("#operations-default-download_users_csv_users_download_csv_get")
    locator.get_by_role("button", name="get /users/download/csv", exact=True).click()
    locator.get_by_role("button", name="Try it out").click()
    locator.get_by_role("button", name="Execute").click()
    with page.expect_download() as download_info:
        locator.get_by_role("link", name="Download file").click()
    download = download_info.value
    download.save_as(save_path)

    response_code = locator.get_by_role("table").get_by_role("cell").nth(2).inner_text()
    assert response_code == "200"
