import csv


def load_test_data_from_csv(filepath):
    data = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader)  # Skip header row if present
        for row in reader:
            data.append(tuple(row))  # Or dictionary if using named parameters
    return data
