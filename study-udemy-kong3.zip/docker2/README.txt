Please see more detailed information in each subfolder's README.txt file.
Start with folder "kong", which is the main topic for the course
