Open terminal, and run this command


#> docker-compose up -d