import csv
import io
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, EmailStr, ValidationError

app = FastAPI()

# CORS設定を追加
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 本番環境では適切なオリジンを指定
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ユーザーデータモデル（リクエスト用）
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    age: Optional[int] = None
    is_active: bool = True


# ユーザーデータモデル（レスポンス用）
class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    age: Optional[int]
    is_active: bool
    created_at: datetime


# CSV一括作成結果のレスポンスモデル
class BulkCreateResult(BaseModel):
    success_count: int
    error_count: int
    created_users: List[UserResponse]
    errors: List[dict]


# 簡易的なデータベース（実際の開発では適切なDBを使用）
fake_users_db = []

# FastAPIアプリケーションインスタンス
app = FastAPI()


@app.post("/users", response_model=UserResponse)
async def create_user(user: UserCreate):
    """
    新しいユーザーを作成するエンドポイント
    """
    # メールアドレスの重複チェック
    for existing_user in fake_users_db:
        if existing_user["email"] == user.email:
            raise HTTPException(status_code=400, detail="Email already registered")

    # 新しいユーザーを作成
    new_user = {
        "id": str(uuid.uuid4()),
        "name": user.name,
        "email": user.email,
        "age": user.age,
        "is_active": user.is_active,
        "created_at": datetime.now(),
    }

    # データベースに保存（この例では配列に追加）
    fake_users_db.append(new_user)

    return new_user


@app.post("/users/upload/csv", response_model=BulkCreateResult)
async def upload_users_csv(file: UploadFile = File(...)):
    """
    CSVファイルをアップロードしてユーザーを一括作成するエンドポイント

    CSVフォーマット:
    Name, Email, Age, Is Active

    注意: IDとCreated Atは自動生成されるため、CSVに含める必要はありません
    """
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only CSV files are allowed")

    created_users = []
    errors = []
    success_count = 0
    error_count = 0

    try:
        # ファイル内容を読み込み
        contents = await file.read()
        csv_content = contents.decode("utf-8")

        # CSVを解析
        csv_reader = csv.DictReader(io.StringIO(csv_content))

        # 必要な列が存在するかチェック
        required_columns = {"Name", "Email"}
        if not required_columns.issubset(set(csv_reader.fieldnames)):
            raise HTTPException(status_code=400, detail=f"CSV must contain at least these columns: {required_columns}")

        for row_num, row in enumerate(csv_reader, start=2):  # start=2 because row 1 is header
            try:
                # 空の行をスキップ
                if not any(row.values()):
                    continue

                # データの前処理
                name = row.get("Name", "").strip()
                email = row.get("Email", "").strip()
                age_str = row.get("Age", "").strip()
                is_active_str = row.get("Is Active", "true").strip().lower()

                # 必須フィールドのチェック
                if not name:
                    errors.append({"row": row_num, "error": "Name is required"})
                    error_count += 1
                    continue

                if not email:
                    errors.append({"row": row_num, "error": "Email is required"})
                    error_count += 1
                    continue

                # 年齢の処理
                age = None
                if age_str:
                    try:
                        age = int(age_str)
                        if age < 0 or age > 150:
                            errors.append({"row": row_num, "error": "Age must be between 0 and 150"})
                            error_count += 1
                            continue
                    except ValueError:
                        errors.append({"row": row_num, "error": "Invalid age format"})
                        error_count += 1
                        continue

                # is_activeの処理
                is_active = is_active_str in ["true", "1", "yes", "active"]

                # メールアドレスの重複チェック
                existing_emails = {user["email"] for user in fake_users_db}
                created_emails = {user.email for user in created_users}

                if email in existing_emails or email in created_emails:
                    errors.append({"row": row_num, "error": f"Email {email} already exists"})
                    error_count += 1
                    continue

                # UserCreateモデルでバリデーション
                try:
                    user_data = UserCreate(name=name, email=email, age=age, is_active=is_active)
                except ValidationError as e:
                    errors.append({"row": row_num, "error": str(e)})
                    error_count += 1
                    continue

                # 新しいユーザーを作成
                new_user = {
                    "id": str(uuid.uuid4()),
                    "name": user_data.name,
                    "email": user_data.email,
                    "age": user_data.age,
                    "is_active": user_data.is_active,
                    "created_at": datetime.now(),
                }

                # データベースに追加
                fake_users_db.append(new_user)
                created_users.append(UserResponse(**new_user))
                success_count += 1

            except Exception as e:
                errors.append({"row": row_num, "error": f"Unexpected error: {str(e)}"})
                error_count += 1

    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="Invalid file encoding. Please use UTF-8 encoding.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing CSV file: {str(e)}")

    return BulkCreateResult(
        success_count=success_count, error_count=error_count, created_users=created_users, errors=errors
    )


@app.get("/users/download/csv/template")
async def download_csv_template():
    """
    CSVアップロード用のテンプレートファイルをダウンロードするエンドポイント
    """
    # テンプレートCSVデータを作成
    output = io.StringIO()
    writer = csv.writer(output)

    # ヘッダー行
    writer.writerow(["Name", "Email", "Age", "Is Active"])

    # サンプルデータ
    writer.writerow(["山田太郎", "yamada@example.com", "25", "true"])
    writer.writerow(["佐藤花子", "sato@example.com", "30", "true"])
    writer.writerow(["田中次郎", "tanaka@example.com", "", "false"])

    csv_content = output.getvalue()
    output.close()

    response = StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=user_upload_template.csv"},
    )

    return response


@app.get("/users/download/csv")
async def download_users_csv():
    """
    全ユーザー情報をCSVファイルとしてダウンロードするエンドポイント
    """
    if not fake_users_db:
        raise HTTPException(status_code=404, detail="No users found")

    # CSVデータを作成
    output = io.StringIO()
    writer = csv.writer(output)

    # ヘッダー行を書き込み
    writer.writerow(["ID", "Name", "Email", "Age", "Is Active", "Created At"])

    # ユーザーデータを書き込み
    for user in fake_users_db:
        writer.writerow(
            [
                user["id"],
                user["name"],
                user["email"],
                user["age"] if user["age"] is not None else "",
                user["is_active"],
                user["created_at"].strftime("%Y-%m-%d %H:%M:%S"),
            ]
        )

    # StringIOの内容を取得
    csv_content = output.getvalue()
    output.close()

    # StreamingResponseでCSVファイルとして返す
    response = StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=users.csv"},
    )

    return response


@app.get("/users/download/csv/filtered")
async def download_filtered_users_csv(
    is_active: Optional[bool] = None, min_age: Optional[int] = None, max_age: Optional[int] = None
):
    """
    フィルタ条件に基づいてユーザー情報をCSVファイルとしてダウンロードするエンドポイント

    Parameters:
    - is_active: アクティブ状態でフィルタ (True/False)
    - min_age: 最小年齢でフィルタ
    - max_age: 最大年齢でフィルタ
    """
    # フィルタ条件に基づいてユーザーを絞り込み
    filtered_users = fake_users_db

    if is_active is not None:
        filtered_users = [u for u in filtered_users if u["is_active"] == is_active]

    if min_age is not None:
        filtered_users = [u for u in filtered_users if u["age"] is not None and u["age"] >= min_age]

    if max_age is not None:
        filtered_users = [u for u in filtered_users if u["age"] is not None and u["age"] <= max_age]

    if not filtered_users:
        raise HTTPException(status_code=404, detail="No users found matching the criteria")

    # CSVデータを作成
    output = io.StringIO()
    writer = csv.writer(output)

    # ヘッダー行を書き込み
    writer.writerow(["ID", "Name", "Email", "Age", "Is Active", "Created At"])

    # フィルタされたユーザーデータを書き込み
    for user in filtered_users:
        writer.writerow(
            [
                user["id"],
                user["name"],
                user["email"],
                user["age"] if user["age"] is not None else "",
                user["is_active"],
                user["created_at"].strftime("%Y-%m-%d %H:%M:%S"),
            ]
        )

    # StringIOの内容を取得
    csv_content = output.getvalue()
    output.close()

    # ファイル名にフィルタ情報を含める
    filename = "users_filtered"
    if is_active is not None:
        filename += f"_active_{is_active}"
    if min_age is not None:
        filename += f"_min_age_{min_age}"
    if max_age is not None:
        filename += f"_max_age_{max_age}"
    filename += ".csv"

    # StreamingResponseでCSVファイルとして返す
    response = StreamingResponse(
        io.StringIO(csv_content),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )

    return response


@app.get("/users")
async def get_users():
    """
    全ユーザーを取得するエンドポイント（確認用）
    """
    return fake_users_db


@app.get("/users/{user_id}")
async def get_user(user_id: str):
    """
    特定のユーザーを取得するエンドポイント
    """
    for user in fake_users_db:
        if user["id"] == user_id:
            return user

    raise HTTPException(status_code=404, detail="User not found")


# サーバー起動用のメイン関数
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
